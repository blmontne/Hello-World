if(payload.contains("Sample ID:")){
	def matcher = payload =~ /[0-9]+/
	id = matcher[0]
	payload = null;
	return message.setInvocationProperty('sampleId',id);
} else {
	return payload;
}